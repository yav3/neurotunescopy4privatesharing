import React from 'react';
import { LoginForm } from '@/components/auth/LoginForm';

export function AuthPage() {
  return (
    <div
      className="min-h-screen flex items-center justify-center px-4"
      style={{ background: '#000' }}
    >
      {/* Background ambient glow */}
      <div
        className="fixed inset-0 pointer-events-none"
        style={{
          background: `
            radial-gradient(ellipse at 20% 50%, rgba(100, 100, 255, 0.05) 0%, transparent 60%),
            radial-gradient(ellipse at 80% 20%, rgba(100, 200, 255, 0.05) 0%, transparent 60%)
          `,
        }}
      />

      <div className="relative z-10 w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <h1
            className="text-4xl font-bold tracking-tight"
            style={{ color: '#C0C0C8' }}
          >
            NeuroTunes
          </h1>
          <p className="mt-2 text-sm" style={{ color: '#C0C0C8', opacity: 0.5 }}>
            Therapeutic Music Platform
          </p>
        </div>

        {/* Auth card */}
        <div
          className="rounded-2xl p-8"
          style={{
            background: 'rgba(10, 10, 10, 0.8)',
            backdropFilter: 'blur(20px)',
            border: '1px solid rgba(255, 255, 255, 0.08)',
            boxShadow: '0 25px 60px rgba(0, 0, 0, 0.8)',
          }}
        >
          <LoginForm />
        </div>

        <p className="text-center mt-6 text-xs" style={{ color: '#C0C0C8', opacity: 0.3 }}>
          © Neural Positive Tech Inc. — Invite only.
        </p>
      </div>
    </div>
  );
}

export default AuthPage;
