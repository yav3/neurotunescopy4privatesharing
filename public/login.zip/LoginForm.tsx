import React, { useState, useEffect } from 'react';
import { Mail, AlertTriangle, ArrowLeft, ShieldCheck } from 'lucide-react';
import { useAuthContext } from './AuthProvider';
import { useNavigate } from 'react-router-dom';

const inputStyle = {
  background: 'rgba(0, 0, 0, 0.6)',
  backdropFilter: 'blur(10px)',
  border: '1px solid rgba(255, 255, 255, 0.2)',
  color: '#C0C0C8',
};

const buttonStyle = {
  background: 'rgba(0, 0, 0, 0.8)',
  backdropFilter: 'blur(20px)',
  border: 'none',
  boxShadow: `
    0 0 0 1px rgba(255, 255, 255, 0.3),
    inset 0 2px 8px rgba(255, 255, 255, 0.1),
    inset 0 -2px 8px rgba(0, 0, 0, 0.5),
    0 8px 32px rgba(0, 0, 0, 0.6)
  `,
  color: '#C0C0C8',
};

export function LoginForm() {
  const { sendOtp, verifyOtp, loading, error, clearError, otpSent, otpEmail, resetOtp, user } = useAuthContext();
  const [email, setEmail] = useState('');
  const [inviteCode, setInviteCode] = useState('');
  const [otp, setOtp] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    if (user) {
      console.log('✅ User authenticated, redirecting to music player');
      navigate('/goals');
    }
  }, [user, navigate]);

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    clearError();
    await sendOtp(email, inviteCode);
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    clearError();
    await verifyOtp(otpEmail, otp);
  };

  const handleOtpChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    // Only allow digits, max 6
    const val = e.target.value.replace(/\D/g, '').slice(0, 6);
    setOtp(val);
  };

  const handleResend = async () => {
    clearError();
    setOtp('');
    await sendOtp(otpEmail);
  };

  return (
    <div className="w-full max-w-md space-y-6">
      {/* Header */}
      <div className="text-center">
        <div className="flex justify-center mb-4">
          <ShieldCheck className="w-10 h-10" style={{ color: '#C0C0C8' }} />
        </div>
        <h2 className="text-3xl font-bold mb-2" style={{ color: '#C0C0C8' }}>
          {otpSent ? 'Check Your Email' : 'Welcome to NeuroTunes'}
        </h2>
        <p style={{ color: '#C0C0C8', opacity: 0.7 }}>
          {otpSent
            ? `We sent a 6-digit code to ${otpEmail}`
            : 'Enter your access code and email to continue'}
        </p>
      </div>

      {/* Error */}
      {error && (
        <div
          className="rounded-lg p-4"
          style={{
            background: 'rgba(220, 38, 38, 0.15)',
            border: '1px solid rgba(220, 38, 38, 0.3)',
            backdropFilter: 'blur(10px)',
          }}
        >
          <div className="flex items-center">
            <AlertTriangle className="w-5 h-5 mr-2 flex-shrink-0" style={{ color: '#fca5a5' }} />
            <p className="text-sm" style={{ color: '#fca5a5' }}>{error}</p>
          </div>
        </div>
      )}

      {/* Step 1: Email + Invite Code */}
      {!otpSent && (
        <form onSubmit={handleSendOtp} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2" style={{ color: '#C0C0C8' }}>
              Access Code
            </label>
            <input
              type="text"
              value={inviteCode}
              onChange={(e) => setInviteCode(e.target.value)}
              style={inputStyle}
              className="w-full px-4 py-3 rounded-lg placeholder:text-gray-500 focus:outline-none focus:ring-1 focus:ring-white/30 transition-all"
              placeholder="Enter your invitation code"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2" style={{ color: '#C0C0C8' }}>
              Email Address
            </label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5" style={{ color: '#C0C0C8' }} />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                style={inputStyle}
                className="w-full pl-10 pr-4 py-3 rounded-lg placeholder:text-gray-500 focus:outline-none focus:ring-1 focus:ring-white/30 transition-all"
                placeholder="Enter your email"
                required
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading || !email || !inviteCode}
            className="w-full py-3 px-4 rounded-lg font-medium focus:outline-none disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
            style={buttonStyle}
          >
            {loading ? 'Sending code...' : 'Send Verification Code'}
          </button>
        </form>
      )}

      {/* Step 2: OTP entry */}
      {otpSent && (
        <form onSubmit={handleVerifyOtp} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2" style={{ color: '#C0C0C8' }}>
              6-Digit Verification Code
            </label>
            <input
              type="text"
              inputMode="numeric"
              pattern="[0-9]*"
              value={otp}
              onChange={handleOtpChange}
              style={{
                ...inputStyle,
                fontSize: '2rem',
                letterSpacing: '0.5em',
                textAlign: 'center',
              }}
              className="w-full px-4 py-4 rounded-lg focus:outline-none focus:ring-1 focus:ring-white/30 transition-all"
              placeholder="000000"
              maxLength={6}
              required
              autoFocus
            />
          </div>

          <button
            type="submit"
            disabled={loading || otp.length !== 6}
            className="w-full py-3 px-4 rounded-lg font-medium focus:outline-none disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
            style={buttonStyle}
          >
            {loading ? 'Verifying...' : 'Verify & Sign In'}
          </button>

          <div className="text-center space-y-3 pt-2">
            <button
              type="button"
              onClick={handleResend}
              disabled={loading}
              className="text-sm font-medium transition-colors"
              style={{ color: '#C0C0C8', opacity: 0.7 }}
            >
              Didn't get it? Resend code
            </button>
            <div>
              <button
                type="button"
                onClick={resetOtp}
                className="text-sm flex items-center gap-1 mx-auto transition-colors"
                style={{ color: '#C0C0C8', opacity: 0.5 }}
              >
                <ArrowLeft className="w-3 h-3" />
                Use a different email
              </button>
            </div>
          </div>
        </form>
      )}

      {/* Footer note */}
      <p className="text-xs text-center" style={{ color: '#C0C0C8', opacity: 0.4 }}>
        No password required. Codes expire after 60 seconds.
      </p>
    </div>
  );
}
