import { useState, useEffect, useCallback } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';

export type UserRole = 'admin' | 'user' | 'premium';

export interface UserProfile {
  id: string;
  email: string;
  display_name?: string;
  role: UserRole;
  avatar_url?: string;
}

export interface AuthState {
  user: User | null;
  session: Session | null;
  profile: UserProfile | null;
  loading: boolean;
  error: string | null;
  otpSent: boolean;
  otpEmail: string;
}

export interface AuthActions {
  sendOtp: (email: string, inviteCode?: string) => Promise<void>;
  verifyOtp: (email: string, token: string) => Promise<void>;
  signOut: () => Promise<void>;
  updateProfile: (updates: Partial<UserProfile>) => Promise<void>;
  clearError: () => void;
  resetOtp: () => void;
}

export function useAuth(): AuthState & AuthActions {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [otpSent, setOtpSent] = useState(false);
  const [otpEmail, setOtpEmail] = useState('');

  const fetchProfile = useCallback(async (userId: string, userEmail: string) => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .maybeSingle();

      if (error) throw error;

      if (data) {
        setProfile({
          id: data.id,
          email: userEmail,
          display_name: data.display_name,
          role: (data.role as UserRole) || 'user',
          avatar_url: data.avatar_url,
        });
      } else {
        // Auto-create profile on first OTP login
        const { data: newProfile, error: insertError } = await supabase
          .from('profiles')
          .insert({ id: userId, email: userEmail, role: 'user' })
          .select()
          .single();
        if (!insertError && newProfile) {
          setProfile({
            id: newProfile.id,
            email: userEmail,
            display_name: newProfile.display_name,
            role: 'user',
            avatar_url: newProfile.avatar_url,
          });
        }
      }
    } catch (err) {
      console.error('Error fetching profile:', err);
    }
  }, []);

  useEffect(() => {
    // Get initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      if (session?.user) {
        fetchProfile(session.user.id, session.user.email ?? '');
      }
      setLoading(false);
    });

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (_event, session) => {
        setSession(session);
        setUser(session?.user ?? null);
        if (session?.user) {
          await fetchProfile(session.user.id, session.user.email ?? '');
        } else {
          setProfile(null);
        }
        setLoading(false);
      }
    );

    return () => subscription.unsubscribe();
  }, [fetchProfile]);

  // Step 1: Send OTP to email
  const sendOtp = useCallback(async (email: string, inviteCode?: string) => {
    setLoading(true);
    setError(null);
    try {
      // Optional: validate invite code before sending OTP
      if (inviteCode !== undefined) {
        const validCodes = ['founders_vip', 'beta_access', 'nt_invite'];
        if (!validCodes.includes(inviteCode.toLowerCase().trim())) {
          throw new Error('Invalid access code. Please contact NeuroTunes for an invitation.');
        }
      }

      const { error } = await supabase.auth.signInWithOtp({
        email,
        options: {
          shouldCreateUser: true, // auto-creates account on first use
        },
      });

      if (error) throw error;

      setOtpEmail(email);
      setOtpSent(true);
    } catch (err: any) {
      setError(err.message || 'Failed to send verification code');
    } finally {
      setLoading(false);
    }
  }, []);

  // Step 2: Verify the 6-digit OTP
  const verifyOtp = useCallback(async (email: string, token: string) => {
    setLoading(true);
    setError(null);
    try {
      const { error } = await supabase.auth.verifyOtp({
        email,
        token,
        type: 'email',
      });

      if (error) throw error;
      // onAuthStateChange will handle setting user/session/profile
    } catch (err: any) {
      setError(err.message || 'Invalid or expired code. Please try again.');
    } finally {
      setLoading(false);
    }
  }, []);

  const signOut = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      setOtpSent(false);
      setOtpEmail('');
    } catch (err: any) {
      setError(err.message || 'Failed to sign out');
    } finally {
      setLoading(false);
    }
  }, []);

  const updateProfile = useCallback(async (updates: Partial<UserProfile>) => {
    if (!user) return;
    setLoading(true);
    setError(null);
    try {
      const { error } = await supabase
        .from('profiles')
        .update(updates)
        .eq('id', user.id);
      if (error) throw error;
      setProfile(prev => prev ? { ...prev, ...updates } : null);
    } catch (err: any) {
      setError(err.message || 'Failed to update profile');
    } finally {
      setLoading(false);
    }
  }, [user]);

  const clearError = useCallback(() => setError(null), []);
  const resetOtp = useCallback(() => {
    setOtpSent(false);
    setOtpEmail('');
    setError(null);
  }, []);

  return {
    user,
    session,
    profile,
    loading,
    error,
    otpSent,
    otpEmail,
    sendOtp,
    verifyOtp,
    signOut,
    updateProfile,
    clearError,
    resetOtp,
  };
}
